package com.collegesoft.carservice.model;

import java.util.Date;

public class CarRent {
    private Date startDate;
    private Date endDate;
}
