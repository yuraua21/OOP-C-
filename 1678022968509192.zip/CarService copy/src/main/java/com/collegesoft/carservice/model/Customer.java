package com.collegesoft.carservice.model;

import lombok.Getter;
import lombok.Setter;

public class Customer {
    @Getter
    @Setter
    private int rentAmountTimes;
}
